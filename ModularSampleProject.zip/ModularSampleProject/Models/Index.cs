﻿namespace ModularSampleProject.Models
{
    public class Index
    {
    }
}
